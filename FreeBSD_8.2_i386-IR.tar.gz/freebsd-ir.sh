# Adaptation of the linux-ir.sh script from SANS / Helix CD for FreeBSD by Nicolas Villatte.
# Feel free to contact me for any bug or enhancement request (e.g. if you find ways to have some information from the filesystem avoiding to run commands).
# The script has been tested on FreeBSD_8.2-RELEASE_i386, it may not work properly on other releases and would require another set of statically compiled binaries on another platform architecture.
# References: http://antapex.org/unixcommands.txt & http://cb.vu/unixtoolbox.xhtml
# Usage: 
#		Burn the script and the trusted binaries folder preferably to a non-rewritable media
#		Logged as Root, attach and mount the binaries and target medias to the system (e.g. for a CD|DVD-ROM use mount_cd9660)
#		Run the command "sh freebsd-ir.sh > /<targetmedia>/<outputfilename>"
#		Make sure you hash your output file with at least md5 on the target media
# Last Updated 2013-08-27
#!/bin/bash

CURDIR=`./FreeBSD_8.2-RELEASE_i386/pwd`
BINDIR="$CURDIR/FreeBSD_8.2-RELEASE_i386"
$BINDIR/echo "All output can be redirected to your choice of storage or netcat pipe."

$BINDIR/echo "========="
$BINDIR/echo "hostname:"
$BINDIR/echo "========="
$BINDIR/hostname
$BINDIR/echo 
$BINDIR/echo "========="
$BINDIR/echo "cpu info:"
$BINDIR/echo "========="
#$BINDIR/cat /proc/cpuinfo 							; for linux, does not work on FreeBSD
$BINDIR/sysctl hw.model
$BINDIR/sysctl hw.ncpu
$BINDIR/echo 
$BINDIR/echo "========="
$BINDIR/echo "disk use:"
$BINDIR/echo "========="
$BINDIR/df -hl
$BINDIR/echo 
$BINDIR/echo "============="
$BINDIR/echo "fdisk output:"
$BINDIR/echo "============="
#fdisk -l 															; for linux, does not work on freeBSD
$BINDIR/fdisk -p
$BINDIR/echo 
$BINDIR/echo "========="
$BINDIR/echo "version:"
$BINDIR/echo "========="
#$BINDIR/cat /proc/version 							; for linux, does not work on FreeBSD
$BINDIR/uname -a
$BINDIR/echo 
$BINDIR/echo "==================="
$BINDIR/echo "kernel boot params:"
$BINDIR/echo "==================="
#$BINDIR/cat /proc/cmdline 							; for linux, does not work on FreeBSD
$BINDIR/sysctl kern
$BINDIR/echo 
$BINDIR/echo "=================================="
$BINDIR/echo "Local shell environment variables:"
$BINDIR/echo "=================================="
$BINDIR/env
$BINDIR/echo 
$BINDIR/echo "=========================="
$BINDIR/echo "currently logged in users:"
$BINDIR/echo "=========================="
$BINDIR/who
$BINDIR/echo 
$BINDIR/echo "=========================="
$BINDIR/echo "List of running processes:"
$BINDIR/echo "=========================="
$BINDIR/ps -efl
$BINDIR/echo 
$BINDIR/procstat -a
$BINDIR/echo
$BINDIR/echo "======================"
$BINDIR/echo "Network interface info"
$BINDIR/echo "======================"
$BINDIR/ifconfig -a
$BINDIR/echo
#$BINDIR/ifconfig -s 										; for linux, does not work on FreeBSD
$BINDIR/netstat -ain
$BINDIR/echo
$BINDIR/echo "=================="
$BINDIR/echo "arp table entries:"
$BINDIR/echo "=================="
$BINDIR/arp -an
$BINDIR/echo
$BINDIR/echo "=================="
$BINDIR/echo "/etc/hosts file:"
$BINDIR/echo "=================="
$BINDIR/cat /etc/hosts
$BINDIR/echo
$BINDIR/echo "======================"
$BINDIR/echo "/etc/resolv.conf file:"
$BINDIR/echo "======================"
$BINDIR/cat /etc/resolv.conf
$BINDIR/echo
$BINDIR/echo "======================"
$BINDIR/echo "/etc/passwd file:"
$BINDIR/echo "======================"
$BINDIR/cat /etc/passwd
$BINDIR/echo
$BINDIR/echo "======================"
$BINDIR/echo "/etc/shadow file:"
$BINDIR/echo "======================"
#$BINDIR/cat /etc/shadow for linux, does not work on FreeBSD
$BINDIR/cat /etc/master.passwd
$BINDIR/echo
$BINDIR/echo "==================================="
$BINDIR/echo "netstat output(current connections)"
$BINDIR/echo "==================================="
#$BINDIR/netstat -anp 									; for linux, does not work on FreeBSD
$BINDIR/netstat -an
$BINDIR/sockstat
$BINDIR/echo
$BINDIR/echo "=============="
$BINDIR/echo "routing table:"
$BINDIR/echo "=============="
$BINDIR/netstat -rn
$BINDIR/echo
$BINDIR/echo "==============="
$BINDIR/echo "firewall table:"
$BINDIR/echo "==============="
$BINDIR/ipfw show
$BINDIR/ipfw list
$BINDIR/echo
$BINDIR/echo "==========================="
$BINDIR/echo "listening ports (via lsof):"
$BINDIR/echo "==========================="
$BINDIR/lsof -P -i -n
$BINDIR/echo
$BINDIR/echo "============"
$BINDIR/echo "lsof output:"
$BINDIR/echo "============"
$BINDIR/lsof 
$BINDIR/echo
$BINDIR/echo "============"
$BINDIR/echo "Memory info:"
$BINDIR/echo "============"
#$BINDIR/cat /proc/meminfo 							; for linux, does not work on FreeBSD
$BINDIR/sysctl vm
$BINDIR/sysctl hw.realmem
$BINDIR/echo 
$BINDIR/echo "============"
$BINDIR/echo "Module info:"
$BINDIR/echo "============"
#$BINDIR/cat /proc/modules 							; for linux, does not work on FreeBSD
$BINDIR/kldstat -v
$BINDIR/echo 
$BINDIR/echo "==========="
$BINDIR/echo "Mount info:"
$BINDIR/echo "==========="
#$BINDIR/cat /proc/mounts 							; for linux, does not work on FreeBSD
$BINDIR/mount
$BINDIR/echo
$BINDIR/echo "=========="
$BINDIR/echo "Swap info:"
$BINDIR/echo "=========="
#$BINDIR/cat /proc/swaps 								; for linux, does not work on FreeBSD
$BINDIR/pstat -s
$BINDIR/echo 
$BINDIR/echo "==========="
$BINDIR/echo "  fstab:   "
$BINDIR/echo "==========="
$BINDIR/cat /etc/fstab
$BINDIR/echo 
$BINDIR/echo "==========="
$BINDIR/echo "  labels:  "
$BINDIR/echo "==========="
$BINDIR/glabel list
$BINDIR/echo 
$BINDIR/echo "================"
$BINDIR/echo "  PCI devices:  "
$BINDIR/echo "================"
$BINDIR/pciconf -lcv
$BINDIR/echo 
$BINDIR/echo "================"
$BINDIR/echo "  USB devices:  "
$BINDIR/echo "================"
$BINDIR/usbconfig
$BINDIR/echo 
$BINDIR/echo "================"
$BINDIR/echo "  HAL devices:  "
$BINDIR/echo "================"
$BINDIR/atacontrol list
$BINDIR/echo 
$BINDIR/echo "================"
$BINDIR/echo "  ATA devices:  "
$BINDIR/echo "================"
$BINDIR/camcontrol devlist -v
$BINDIR/echo 
$BINDIR/echo "==============="
$BINDIR/echo "    sysctl:    "
$BINDIR/echo "==============="
$BINDIR/sysctl -a
$BINDIR/echo 
$BINDIR/echo "================================================================"
$BINDIR/echo "Running Process info:                                           "
$BINDIR/echo "================================================================"
$BINDIR/fstat
$BINDIR/echo
$BINDIR/echo "========================================================"
$BINDIR/echo
$BINDIR/mount -t procfs proc /proc
$BINDIR/ls /proc | sort -n | grep -v [a-z,A-Z] | while read PID
  do
	$BINDIR/echo "Process ID $PID:"
	$BINDIR/echo "/proc/$PID/cmdline:"
	$BINDIR/cat /proc/$PID/cmdline
	$BINDIR/echo
#	$BINDIR/echo													; for linux, does not work on FreeBSD
#	$BINDIR/echo "/proc/$PID/environ:"		
#	$BINDIR/cat /proc/$PID/environ				
#	$BINDIR/echo													
	$BINDIR/echo
	$BINDIR/echo "/proc/$PID/etype:"
	$BINDIR/cat /proc/$PID/etype
	$BINDIR/echo
	$BINDIR/echo
	$BINDIR/echo "/proc/$PID/maps:"
#	$BINDIR/cat /proc/$PID/maps						; for linux, does not work on FreeBSD
	$BINDIR/cat /proc/$PID/map
	$BINDIR/echo
#	$BINDIR/echo													; for linux, does not work on FreeBSD
#	$BINDIR/echo "/proc/$PID/stat:"
#	$BINDIR/cat /proc/$PID/stat
#	$BINDIR/echo
#	$BINDIR/echo													; for linux, does not work on FreeBSD
#	$BINDIR/echo "/proc/$PID/statm:"
#	$BINDIR/cat /proc/$PID/statm
#	$BINDIR/echo
	$BINDIR/echo
	$BINDIR/echo "/proc/$PID/status:"
	$BINDIR/cat /proc/$PID/status
	$BINDIR/echo
	$BINDIR/echo
	$BINDIR/echo "/proc/$PID/mem:"
	$BINDIR/cat /proc/$PID/mem
	$BINDIR/echo
	$BINDIR/echo
	$BINDIR/echo
	$BINDIR/echo "/proc/$PID/osrel:"
	$BINDIR/cat /proc/$PID/osrel
	$BINDIR/echo
	$BINDIR/echo
	$BINDIR/echo "/proc/$PID/rlimit:"
	$BINDIR/cat /proc/$PID/rlimit
#	$BINDIR/echo													; for linux, does not work on FreeBSD
#	$BINDIR/echo "/proc/$PID/root:"
#	$BINDIR/ls -ld /proc/$PID/root
#	$BINDIR/echo													; for linux, does not work on FreeBSD
#	$BINDIR/echo "/proc/$PID/cwd:"
#	$BINDIR/ls -ld /proc/$PID/cwd
#	$BINDIR/echo													; for linux, does not work on FreeBSD
#	$BINDIR/echo "/proc/$PID/exe:"
#	$BINDIR/ls -ld /proc/$PID/exe
#	$BINDIR/echo
	$BINDIR/echo
	$BINDIR/echo "/proc/$PID/file:"
	$BINDIR/ls -ld /proc/$PID/file
#	$BINDIR/echo													; for linux, does not work on FreeBSD
#	$BINDIR/echo "/proc/$PID/fd/*:"
#	$BINDIR/ls -lrta /proc/$PID/fd/
	$BINDIR/echo
	$BINDIR/echo "========================================================"
	$BINDIR/echo
  done
$BINDIR/umount /proc
$BINDIR/echo
# The elements below have been collected as they are not volatile data; you may want to uncomment them if you are performing triage
#
#$BINDIR/echo "================="
#$BINDIR/echo "SUID/SGID search:"
#$BINDIR/echo "================="
#$BINDIR/echo 
##$BINDIR/find / -perm -2000 -o -perm -4000 -print -exec "$BINDIR/xargs $BINDIR/ls -ldb {}" \;		; for linux, does not work on FreeBSD
#$BINDIR/ls -ldb `$BINDIR/find / -perm -2000 -o -perm -4000 -print`
#$BINDIR/echo 
#$BINDIR/echo "================="
#$BINDIR/echo "File permissions:"
#$BINDIR/echo "================="
#$BINDIR/echo "/etc:"
#$BINDIR/echo "-----"
#$BINDIR/ls -lrta /etc
#$BINDIR/echo
#$BINDIR/echo "/bin:"
#$BINDIR/echo "-----"
#$BINDIR/ls -lrta /bin
#$BINDIR/echo
#$BINDIR/echo "/sbin:"
#$BINDIR/echo "------"
#$BINDIR/ls -lrta /sbin
#$BINDIR/echo
#$BINDIR/echo "/usr:"
#$BINDIR/echo "-----"
#$BINDIR/ls -Rlrta /usr
#$BINDIR/echo
#$BINDIR/echo "/var:"
#$BINDIR/echo "-----"
#$BINDIR/ls -Rlrta /var
#$BINDIR/echo
#$BINDIR/echo "/dev:"
#$BINDIR/echo "-----"
#$BINDIR/ls -Rlrta /dev
#$BINDIR/echo
#$BINDIR/echo "/home:"
#$BINDIR/echo "------"
#$BINDIR/ls -Rlrta /home	$BINDIR/echo
#$BINDIR/echo "/lib:"
#$BINDIR/echo "------"
#$BINDIR/ls -Rlrta /lib
#$BINDIR/echo
#$BINDIR/echo "========================================================"
#$BINDIR/echo "================="
#$BINDIR/echo "MD5SUMs:"
#$BINDIR/echo "================="
#$BINDIR/echo "/etc:"
#$BINDIR/echo "-----"
#$BINDIR/md5 /etc/*
#$BINDIR/echo
#$BINDIR/echo "/bin:"
#$BINDIR/echo "-----"
#$BINDIR/md5 /bin/*
#$BINDIR/echo
#$BINDIR/echo "/sbin:"
#$BINDIR/echo "------"
#$BINDIR/md5 /sbin/*
#$BINDIR/echo
#$BINDIR/echo "/usr:"
#$BINDIR/echo "-----"
#$BINDIR/md5 /usr/*
#$BINDIR/echo
#$BINDIR/echo "/var:"
#$BINDIR/echo "-----"
#$BINDIR/md5 /var/*
#$BINDIR/echo
#$BINDIR/echo "========================================================"

#$BINDIR/echo "Make sure to grab Memory (/proc/kcore" for linux, does not work on FreeBSD (use memdump)
